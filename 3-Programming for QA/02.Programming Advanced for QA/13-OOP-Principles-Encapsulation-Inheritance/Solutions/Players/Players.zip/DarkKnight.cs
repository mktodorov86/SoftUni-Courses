﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Players
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string username, int level) : base(username, level)
        {
        }
    }
}
