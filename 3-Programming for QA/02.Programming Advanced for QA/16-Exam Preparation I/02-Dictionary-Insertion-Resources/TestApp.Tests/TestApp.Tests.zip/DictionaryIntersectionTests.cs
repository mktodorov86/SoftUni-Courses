using System.Collections.Generic;
using NUnit.Framework;

namespace TestApp.Tests
{
    [TestFixture]
    public class DictionaryIntersectionTests
    {
        [Test]
        public void Test_Intersect_TwoEmptyDictionaries_ReturnsEmptyDictionary()
        {
            // Arrange
            var dict1 = new Dictionary<string, int>();
            var dict2 = new Dictionary<string, int>();

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void Test_Intersect_OneEmptyDictionaryAndOneNonEmptyDictionary_ReturnsEmptyDictionary()
        {
            // Arrange
            var dict1 = new Dictionary<string, int>();
            var dict2 = new Dictionary<string, int> { { "a", 1 }, { "b", 2 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void Test_Intersect_TwoNonEmptyDictionariesWithNoCommonKeys_ReturnsEmptyDictionary()
        {
            // Arrange
            var dict1 = new Dictionary<string, int> { { "a", 1 }, { "b", 2 } };
            var dict2 = new Dictionary<string, int> { { "c", 3 }, { "d", 4 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void Test_Intersect_TwoNonEmptyDictionariesWithCommonKeysAndValues_ReturnsIntersectionDictionary()
        {
            // Arrange
            var dict1 = new Dictionary<string, int> { { "a", 1 }, { "b", 2 } };
            var dict2 = new Dictionary<string, int> { { "a", 1 }, { "c", 3 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            var expected = new Dictionary<string, int> { { "a", 1 } };
            Assert.That(result, Is.EquivalentTo(expected));
        }

        [Test]
        public void Test_Intersect_TwoNonEmptyDictionariesWithCommonKeysAndDifferentValues_ReturnsEmptyDictionary()
        {
            // Arrange
            var dict1 = new Dictionary<string, int> { { "a", 1 }, { "b", 2 } };
            var dict2 = new Dictionary<string, int> { { "a", 2 }, { "b", 3 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void Test_Intersect_DictionariesWithSubsetKeys_ReturnsOnlyCommonKeysWithSameValues()
        {
            // Arrange
            var dict1 = new Dictionary<string, int> { { "a", 1 }, { "b", 2 }, { "c", 3 } };
            var dict2 = new Dictionary<string, int> { { "b", 2 }, { "c", 3 }, { "d", 4 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            var expected = new Dictionary<string, int> { { "b", 2 }, { "c", 3 } };
            Assert.That(result, Is.EquivalentTo(expected));
        }

        [Test]
        public void Test_Intersect_DictionariesWithDuplicateValues_ReturnsCorrectIntersection()
        {
            // Arrange
            var dict1 = new Dictionary<string, int> { { "a", 1 }, { "b", 2 } };
            var dict2 = new Dictionary<string, int> { { "a", 2 }, { "b", 2 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            // Since 'a' has different values in the two dictionaries, it should not be in the intersection.
            // 'b' has the same value in both dictionaries, so it should be included in the result.
            var expected = new Dictionary<string, int> { { "b", 2 } };
            Assert.That(result, Is.EquivalentTo(expected));
        }

        [Test]
        public void Test_Intersect_DictionariesWithDifferentDataTypes_ReturnsEmptyDictionary()
        {
            // Arrange
            var dict1 = new Dictionary<string, int> { { "x", 100 } };
            var dict2 = new Dictionary<string, int> { { "y", 200 } };

            // Act
            var result = DictionaryIntersection.Intersect(dict1, dict2);

            // Assert
            Assert.That(result, Is.Empty);
        }
    }
}
