﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System.Net;

namespace ApiTests
{
    [TestFixture]
    public class BookCategoryTests : IDisposable
    {
        private RestClient client;
        private string token;

        [SetUp]
        public void Setup()
        {
            client = new RestClient(GlobalConstants.BaseUrl);
            token = GlobalConstants.AuthenticateUser("john.doe@example.com", "password123");

            Assert.That(token, Is.Not.Null.Or.Empty, "Authentication token should not be null or empty");
        }

        [Test]
        public void Test_BookCategoryLifecycle()
        {
            // Step 1: Create a new book category


            // Step 2: Retrieve all book categories and verify the newly created category is present


            // Step 3: Update the category title


            // Step 4: Verify that the category details have been updated


            // Step 5: Delete the category and validate it's no longer accessible
            

            // Step 6: Verify that the deleted category cannot be found
            
        }

        public void Dispose()
        {
            client?.Dispose();
        }
    }
}
