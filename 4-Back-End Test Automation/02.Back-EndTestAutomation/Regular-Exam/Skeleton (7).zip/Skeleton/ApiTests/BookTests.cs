﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System.Net;

namespace ApiTests
{
    [TestFixture]
    public class BookTests : IDisposable
    {
        private RestClient client;
        private string token;

        [SetUp]
        public void Setup()
        {
            client = new RestClient(GlobalConstants.BaseUrl);
            token = GlobalConstants.AuthenticateUser("john.doe@example.com", "password123");

            Assert.That(token, Is.Not.Null.Or.Empty, "Authentication token should not be null or empty");
        }

        [Test]
        public void Test_GetAllBooks()
        {
        }

        [Test]
        public void Test_GetBookByTitle()
        {
        }

        [Test]
        public void Test_AddBook()
        {
        }

        [Test]
        public void Test_UpdateBook()
        {
        }

        [Test]
        public void Test_DeleteBook()
        {
        }

        public void Dispose()
        {
            client?.Dispose();
        }
    }
}
